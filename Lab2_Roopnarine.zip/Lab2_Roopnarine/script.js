/**
 * Created by 001333352 on 4/3/2017.
 */

/*Andrew Roopnarine
 April 10, 2017
 SE251.55 Advanced Javascript
 Lab 2
 SCRAP SCRIPT FILE | DO NOT LINK FOR USE
 */

//Creating the table and populating it with data from the randomNumber function

//
var wrapper = document.getElementsByClassName("grid")[0];
var str = "<table>";
wrapper.innerHTML = "<table>";
var tbl = [];

for (var rows = 0; rows < tblSize; rows++)
{
    str += "<tr>";
    tbl.push([]);
    for (var columns = 0; columns < tblSize; columns++)
    {
        tbl[rows][columns] = columns;
        str += "<td>";
        str += randomNumber(1, 100);
        str += "</td>";

    }

    str += "</tr>";

}

str += "</table>";

wrapper.innerHTML = str;

console.log(tbl);

//Random Number function

function randomNumber (min, max) {

    return Math.floor (Math.random() * (max - min + 1)) + min;

}


//Button



var txtSize = document.getElementById("tblSize").value;

var tblSize;

btnGen.onclick = genTable;

function genTable() {

    tblSize = (parseInt(txtSize.value));

}


/*var btnGen = document.getElementById("btnGenerate");

btnGen.onclick = function (e) {
    var wrapper = document.getElementsByClassName("grid")[0];
    tblSize = parseInt(document.getElementById("tblSize").value);
    wrapper.innerHTML = tblSize;
    var str = "<table>";
    var tbl = []

    for (var rows = 0; rows < tblSize; rows++)
    {
        str += "<tr>";
        tbl.push([]);
        for (var columns = 0; columns < tblSize; columns++)
        {
            tbl[rows][columns] = columns;
            str += "<td>";
            str += randomNumber(1, 100);
            str += "</td>";

        }

        str += "</tr>";

    }

    str += "</table>";

    wrapper.innerHTML = str;

}*/

if (var x % 2 == 0)
{
    //style.backgroundColor = "red";
}
else if (var x % 3 == 0)
{
    //style.backgroundColor = "blue";
}

//Changing the background of the cell | Red if multiple of 3 | Blue if multiple of 2
for (rows = 0; rows < tblSize; rows++)
{

    for (columns = 0; columns < tblSize; columns++){

        for (var i = 0; i < tbl.length; i++)
        {

            if (num % 2 == 0)
            {
                tbl[rows][columns].style.backgroundColor = "blue";
            }
            else if (num % 3 == 0)
            {
                tbl[rows][columns].style.backgroundColor = "red";
            }

        }

    }

}
