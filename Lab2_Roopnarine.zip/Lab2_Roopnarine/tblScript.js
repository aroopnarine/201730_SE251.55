/**
 * Created by Andrew Roopnarine on 4/3/2017.
 */

/*Andrew Roopnarine
 April 10, 2017
 SE251.55 Advanced Javascript
 Lab 2
 */

//This function generates the random number to be used as parameters for the rows and columns of the table.
function randomNumber (min, max) {

    return Math.floor (Math.random() * (max - min + 1)) + min;

}

//The declared variables sum & avg will be used to calculate the average for all cells
var sum;
var avg;

//This button will be used to generate the table based on the dimensions passed to it by the text box and then clicking
var btnGen = document.getElementById("btnGenerate");

//This function takes the input from the text box, turns it into a number and then passes it into the for loop that
//creates the table as dimensions
 btnGen.onclick = function (e) {
 var wrapper = document.getElementsByClassName("grid")[0];
  //Sum and avg is initialized here in order to reset the values every time the script is run
  sum = 0;
  avg = 0;

 //tblSize is turned into a number from a string from the text box
 tblSize = parseInt(document.getElementById("tblSize").value);
 wrapper.innerHTML = tblSize;
 var str = "<table>";
 var tbl = [];

 //This for loop builds the table based on the tblSize dimensions and the randNum from the generator
 for (var rows = 0; rows < tblSize; rows++)
 {
 str += "<tr>";

 //The .push Array method appends items to the index of the specified array
 tbl.push([]);
 for (var columns = 0; columns < tblSize; columns++)
 {

//Variable num is assigned a random number from the function
var num = randomNumber(1, 100);

  //The <td> tag is being altered based on the following if-statements, it adds in the style tags based on the
  //conditions
 tbl[rows][columns] = num;
  if (num % 2 == 0)
  {
   str += "<td style='background-color: blue'>";
  }
  else if (num % 3 == 0)
  {
   str += "<td style='background-color: red'>";
  }
  else if (num % 2 != 0 && num % 3 != 0)
  {
   str += "<td style='background-color: white'>";
  }
 str += num; //The table data cell is populated by a random number between 1 & 100
 str += "</td>";

//Logs out all cell values by ROW
console.log(tbl[rows][columns]);

  sum += tbl[rows][columns];
  avg = sum / (tblSize * tblSize);

 }

 str += "</tr>";

 }

 str += "</table>";

 wrapper.innerHTML = str;


//Finding the avg of the numbers in the table

  document.getElementById("avg").innerHTML = avg;

//var txtAvg = document.getElementById("avg").innerHTML =

}
